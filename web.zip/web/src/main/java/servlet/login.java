package servlet;

//import java.io.IOException;
import baseDB.usuari;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.*;
import java.io.IOException;

@WebServlet(name = "Login", urlPatterns = {"/login"})
public class login extends HttpServlet {

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        
        String usuario = request.getParameter("usuario");
        String password = request.getParameter("password");

        usuari dao = new usuari();
        boolean valido = dao.validarUsuario(usuario, password);

        if (valido) {
            HttpSession session = request.getSession();
            session.setAttribute("usuario", usuario);
            response.sendRedirect("menu.jsp");
        } else {
            request.setAttribute("error", "Usuari o contrasenya incorrectes.");
            request.getRequestDispatcher("login.jsp").forward(request, response);
        }
    }
}
